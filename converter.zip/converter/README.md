# Sound Converter

A simple web application that allows users to convert audio files to MP3 format with specific settings (44.1kHz sample rate, 16-bit depth).

## Prerequisites

- Python 3.8 or higher
- FFmpeg (required for audio conversion)

## Installation

1. Install FFmpeg:
   - macOS (using Homebrew): `brew install ffmpeg`
   - Linux: `sudo apt-get install ffmpeg`
   - Windows: Download from [FFmpeg website](https://ffmpeg.org/download.html)

2. Install Python dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## Usage

1. Start the application:
   ```bash
   python app.py for linux and macos python3 app.py
   ```

2. Open your web browser and navigate to `http://localhost:5000`

3. Upload an audio file and click "Convert" to convert it to MP3 format

4. The converted file will be automatically downloaded

## Features

- Converts audio files to MP3 format
- Sets sample rate to 44.1kHz
- Sets bit depth to 16-bit
- Modern, responsive UI
- Progress indication
- Error handling

## Supported Input Formats

The application supports various input formats including:
- WAV
- MP3
- OGG
- FLAC
- AAC
- M4A
- WMA

(Note: Actual format support depends on your FFmpeg installation) 