from flask import Flask, request, send_file, render_template
import os
from werkzeug.utils import secure_filename
from pydub import AudioSegment
import logging
import subprocess

app = Flask(__name__)

# Set up logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Set upload folder
UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Ensure upload directory exists
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def convert_with_ffmpeg(input_path, output_path, format_info):
    """Convert audio using FFmpeg directly for better codec support."""
    try:
        command = ['ffmpeg', '-y', '-i', input_path]
        
        # Add format-specific parameters
        if format_info.get('params'):
            command.extend(format_info['params'])
            
        command.append(output_path)
        
        logger.info(f"Running FFmpeg command: {' '.join(command)}")
        result = subprocess.run(command, capture_output=True, text=True)
        
        if result.returncode != 0:
            logger.error(f"FFmpeg error: {result.stderr}")
            raise Exception(f"FFmpeg conversion failed: {result.stderr}")
            
        return True
    except Exception as e:
        logger.error(f"Conversion error: {str(e)}")
        raise

# Format configurations
FORMAT_SETTINGS = {
    'mp3': {
        'ext': 'mp3',
        'mime': 'audio/mpeg',
        'params': ['-acodec', 'libmp3lame', '-ab', '320k']
    },
    'aac': {
        'ext': 'm4a',
        'mime': 'audio/mp4',
        'params': ['-c:a', 'aac', '-b:a', '256k', '-f', 'ipod']
    },
    'flac': {
        'ext': 'flac',
        'mime': 'audio/flac',
        'params': ['-acodec', 'flac']
    },
    'alac': {
        'ext': 'm4a',
        'mime': 'audio/mp4',
        'params': ['-acodec', 'alac', '-f', 'ipod']
    },
    'aiff': {
        'ext': 'aiff',
        'mime': 'audio/aiff',
        'params': ['-f', 'aiff']
    }
}

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        if 'file' not in request.files:
            logger.error("No file part in request")
            return 'No file uploaded', 400
            
        file = request.files['file']
        if file.filename == '':
            logger.error("No file selected")
            return 'No file selected', 400

        # Get the requested format
        output_format = request.form.get('format', 'mp3')
        if output_format not in FORMAT_SETTINGS:
            logger.error(f"Invalid format requested: {output_format}")
            return 'Invalid format selected', 400

        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        logger.info(f"Saving file to {filepath}")
        file.save(filepath)

        try:
            # Log file details
            logger.info(f"Starting conversion of file: {filename}")
            logger.info(f"File exists: {os.path.exists(filepath)}")
            logger.info(f"File size: {os.path.getsize(filepath)} bytes")
            logger.info(f"Converting to format: {output_format}")

            format_info = FORMAT_SETTINGS[output_format]
            converted_filename = f'converted_{filename}.{format_info["ext"]}'
            converted_path = os.path.join(app.config['UPLOAD_FOLDER'], converted_filename)

            # Use FFmpeg directly for AAC and ALAC
            if output_format in ['aac', 'alac']:
                convert_with_ffmpeg(filepath, converted_path, format_info)
            else:
                # Use pydub for other formats
                sound = AudioSegment.from_file(filepath)
                converted_sound = sound.set_frame_rate(44100).set_sample_width(2)
                
                export_kwargs = {
                    'format': format_info['ext']
                }
                
                if 'params' in format_info:
                    export_kwargs['parameters'] = format_info['params']
                
                converted_sound.export(converted_path, **export_kwargs)

            # Verify the converted file exists
            if not os.path.exists(converted_path):
                raise Exception("Converted file was not created")

            logger.info(f"Conversion successful. File size: {os.path.getsize(converted_path)} bytes")

            # Clean up original file
            os.remove(filepath)
            
            return send_file(
                converted_path,
                mimetype=format_info['mime'],
                as_attachment=True,
                download_name=converted_filename
            )
        except Exception as e:
            logger.error(f"Conversion error: {str(e)}", exc_info=True)
            if os.path.exists(filepath):
                os.remove(filepath)
            return f'Error converting file: {str(e)}', 500

    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True, port=5001) 